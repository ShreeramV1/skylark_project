function extractColumnValue(columnValues, columnId) {
  const col = columnValues?.find(c => c.id === columnId);
  return col?.value || null;
}

function cleanValue(value) {
  if (!value || value === 'null' || value === '') {
    return null;
  }
  return String(value).trim();
}

function parseAmount(value) {
  if (!value) return 0;
  const cleaned = cleanValue(value);
  if (!cleaned) return 0;
  const num = parseFloat(String(cleaned).replace(/[^0-9.-]/g, ''));
  return isNaN(num) ? 0 : num;
}

function normalizeDeal(item) {
  const cols = item.column_values || [];

  // Map exact column IDs from the Deals board
  const normalized = {
    id: item.id,
    itemName: item.name,
    dealName: cleanValue(extractColumnValue(cols, 'text_mm2tpbcc')) || cleanValue(item.name) || 'Unnamed Deal',
    ownerCode: cleanValue(extractColumnValue(cols, 'text_mm2t8cez')) || 'N/A',
    clientCode: cleanValue(extractColumnValue(cols, 'text_mm2traps')) || 'N/A',
    dealStatus: cleanValue(extractColumnValue(cols, 'text_mm2tv8w0')) || 'Open',
    closeDate: cleanValue(extractColumnValue(cols, 'text_mm2ttkft')) || null,
    closureProbability: cleanValue(extractColumnValue(cols, 'text_mm2tqgwt')) || 'Medium',
    dealValue: parseAmount(extractColumnValue(cols, 'text_mm2tqs1m')) || 0,
    tentativeCloseDate: cleanValue(extractColumnValue(cols, 'text_mm2ta7gt')) || null,
    dealStage: cleanValue(extractColumnValue(cols, 'text_mm2t9fdj')) || 'Lead',
    productDeal: cleanValue(extractColumnValue(cols, 'text_mm2twmsq')) || 'N/A',
    sector: cleanValue(extractColumnValue(cols, 'text_mm2tfdbc')) || 'Unclassified',
    createdDate: cleanValue(extractColumnValue(cols, 'text_mm2tfhay')) || null,
  };

  return normalized;
}

function normalizeDealsDataset(items) {
  console.log(`\n🔍 [Deals Normalizer] Processing ${items.length} deals...`);
  
  const normalized = items.map(normalizeDeal);

  // Log first 3 items for debugging
  console.log('\n📊 [Deals Normalizer] Sample items (first 3):');
  normalized.slice(0, 3).forEach((item, idx) => {
    console.log(`  Item ${idx + 1}: "${item.dealName}" | Status: ${item.dealStatus} | Value: ₹${item.dealValue} | Sector: ${item.sector}`);
  });

  // Keep all items with valid names
  const filtered = normalized.filter(item => item.dealName !== 'Unnamed Deal' && item.dealName !== null);

  console.log(`✅ [Deals Normalizer] Normalized ${normalized.length} items, kept ${filtered.length} with valid names`);
  
  if (filtered.length > 0) {
    console.log('\n📊 [Deals Normalizer] Data Summary:');
    const sectors = [...new Set(filtered.map(d => d.sector).filter(s => s !== 'Unclassified'))];
    const statuses = [...new Set(filtered.map(d => d.dealStatus))];
    const probabilities = [...new Set(filtered.map(d => d.closureProbability))];
    console.log(`   - Total Deals: ${filtered.length}`);
    console.log(`   - Sectors: ${sectors.join(', ') || 'None'}`);
    console.log(`   - Statuses: ${statuses.join(', ')}`);
    console.log(`   - Probabilities: ${probabilities.join(', ')}`);
    console.log(`   - Total Pipeline Value: ₹${filtered.reduce((sum, d) => sum + d.dealValue, 0).toFixed(2)}`);
  }
  
  return filtered;
}

module.exports = { normalizeDeal, normalizeDealsDataset };