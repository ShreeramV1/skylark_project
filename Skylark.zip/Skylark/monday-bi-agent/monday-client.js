const axios = require('axios');

const MONDAY_API_URL = 'https://api.monday.com/v2';

async function queryMonday(query) {
  try {
    console.log('📡 [Monday API] Sending GraphQL query...');
    const response = await axios.post(
      MONDAY_API_URL,
      { query },
      {
        headers: {
          'Authorization': process.env.MONDAY_API_TOKEN,
          'Content-Type': 'application/json',
        },
      }
    );

    if (response.data.errors) {
      console.error('❌ [Monday API] GraphQL Error:', response.data.errors);
      throw new Error(`GraphQL Error: ${JSON.stringify(response.data.errors)}`);
    }

    console.log('✅ [Monday API] Query successful');
    return response.data;
  } catch (error) {
    console.error('❌ [Monday API] Request failed:', error.message);
    throw error;
  }
}

async function getBoardData(boardId) {
  console.log(`🔍 [Monday API] Fetching board data for board ID: ${boardId}`);
  
  const numericId = parseInt(boardId, 10);
  if (isNaN(numericId)) {
    throw new Error(`Invalid board ID: ${boardId}. Must be numeric.`);
  }

  const query = `
    query {
      boards(ids: [${numericId}]) {
        id
        name
        items_count
        items_page(limit: 500) {
          cursor
          items {
            id
            name
            column_values {
              id
              type
              value
            }
          }
        }
      }
    }
  `;
  
  return queryMonday(query);
}

async function getWorkOrdersData() {
  return getBoardData(process.env.MONDAY_BOARD_ID);
}

async function getDealsData() {
  return getBoardData(process.env.MONDAY_DEALS_BOARD_ID);
}

module.exports = { queryMonday, getBoardData, getWorkOrdersData, getDealsData };