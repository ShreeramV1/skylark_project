// Map Monday.com column IDs to business fields
// You'll need to get these IDs from your board
const COLUMN_MAPPING = {
  'name': 'itemName',
  'text_mm2twjqh': 'dealName',
  'text_mm2tg74x': 'customerCode',
  'text_mm2th93': 'serialNo',
  'text_mm2ttjnt': 'natureOfWork',
  'text_mm2ts5yc': 'lastExecutedMonth',
  'text_mm2txnhh': 'executionStatus',
  'text_mm2tjysd': 'deliveryDate',
  'text_mm2tg5dj': 'poDate',
  'text_mm2tn6nt': 'documentType',
  'text_mm2tftxa': 'probableStartDate',
  'text_mm2tkkav': 'probableEndDate',
  'text_mm2tw3xs': 'bdPersonnel',
  'text_mm2tas1w': 'sector',
  'text_mm2t9w0v': 'typeOfWork',
  'text_mm2t2831': 'skylarkPlatform',
  'text_mm2t2cn0': 'lastInvoiceDate',
  'text_mm2tebgr': 'latestInvoiceNo',
  'text_mm2t8ws': 'amountExclGST',
  'text_mm2t15ye': 'amountInclGST',
  'text_mm2tz8k1': 'billedValueExclGST',
  'text_mm2tch6': 'billedValueInclGST',
  'text_mm2tg2n2': 'collectedAmount',
  'text_mm2t6cs3': 'amountToBilledExclGST',
  'text_mm2t57hh': 'amountToBilledInclGST',
  'text_mm2t8c9q': 'amountReceivable',
  'text_mm2tv1t7': 'arPriority',
  'text_mm2t70z8': 'quantityOps',
  'text_mm2t1bfv': 'quantityPO',
  'text_mm2ter1h': 'quantityBilled',
  'text_mm2tcbcw': 'balanceQuantity',
  'text_mm2trfp2': 'invoiceStatus',
  'text_mm2twtr1': 'expectedBillingMonth',
  'text_mm2t7m13': 'actualBillingMonth',
  'text_mm2t197a': 'actualCollectionMonth',
  'text_mm2tamqt': 'woStatus',
  'text_mm2t1zst': 'collectionStatus',
  'text_mm2tkjm7': 'collectionDate',
  'text_mm2tfd71': 'billingStatus',
};

function extractColumnValue(columnValues, columnId) {
  const col = columnValues?.find(c => c.id === columnId);
  return col?.value || null;
}

function cleanValue(value) {
  if (!value || value === 'null' || value === '') {
    return null;
  }
  return value.trim();
}

function parseAmount(value) {
  if (!value) return 0;
  const cleaned = cleanValue(value);
  if (!cleaned) return 0;
  const num = parseFloat(cleaned.replace(/[^0-9.-]/g, ''));
  return isNaN(num) ? 0 : num;
}

function normalizeWorkOrder(item) {
  const cols = item.column_values || [];

  const normalized = {
    id: item.id,
    itemName: item.name || 'Unknown',
    dealName: cleanValue(extractColumnValue(cols, 'text_mm2twjqh')) || 'Unnamed Deal',
    customerCode: cleanValue(extractColumnValue(cols, 'text_mm2tg74x')) || 'N/A',
    serialNo: cleanValue(extractColumnValue(cols, 'text_mm2th93')) || 'N/A',
    natureOfWork: cleanValue(extractColumnValue(cols, 'text_mm2ttjnt')) || 'N/A',
    executionStatus: cleanValue(extractColumnValue(cols, 'text_mm2txnhh')) || 'Not Started',
    sector: cleanValue(extractColumnValue(cols, 'text_mm2tas1w')) || 'Unclassified',
    typeOfWork: cleanValue(extractColumnValue(cols, 'text_mm2t9w0v')) || 'N/A',
    deliveryDate: cleanValue(extractColumnValue(cols, 'text_mm2tjysd')) || null,
    poDate: cleanValue(extractColumnValue(cols, 'text_mm2tg5dj')) || null,
    lastInvoiceDate: cleanValue(extractColumnValue(cols, 'text_mm2t2cn0')) || null,
    latestInvoiceNo: cleanValue(extractColumnValue(cols, 'text_mm2tebgr')) || 'N/A',
    
    // Financial metrics - parse as numbers
    amountExclGST: parseAmount(extractColumnValue(cols, 'text_mm2t8ws')),
    amountInclGST: parseAmount(extractColumnValue(cols, 'text_mm2t15ye')),
    billedValueExclGST: parseAmount(extractColumnValue(cols, 'text_mm2tz8k1')),
    billedValueInclGST: parseAmount(extractColumnValue(cols, 'text_mm2tch6')),
    collectedAmount: parseAmount(extractColumnValue(cols, 'text_mm2tg2n2')),
    amountReceivable: parseAmount(extractColumnValue(cols, 'text_mm2t8c9q')),
    
    // Status fields
    invoiceStatus: cleanValue(extractColumnValue(cols, 'text_mm2trfp2')) || 'Pending',
    collectionStatus: cleanValue(extractColumnValue(cols, 'text_mm2t1zst')) || 'Pending',
    woStatus: cleanValue(extractColumnValue(cols, 'text_mm2tamqt')) || 'Open',
    billingStatus: cleanValue(extractColumnValue(cols, 'text_mm2tfd71')) || 'Pending',
    
    // Quantity fields
    quantityOps: parseAmount(extractColumnValue(cols, 'text_mm2t70z8')),
    quantityPO: parseAmount(extractColumnValue(cols, 'text_mm2t1bfv')),
    quantityBilled: parseAmount(extractColumnValue(cols, 'text_mm2ter1h')),
    balanceQuantity: parseAmount(extractColumnValue(cols, 'text_mm2tcbcw')),
    
    // Other fields
    bdPersonnel: cleanValue(extractColumnValue(cols, 'text_mm2tw3xs')) || 'N/A',
    arPriority: cleanValue(extractColumnValue(cols, 'text_mm2tv1t7')) || 'N/A',
    skylarkPlatform: cleanValue(extractColumnValue(cols, 'text_mm2t2831')) || 'No',
  };

  return normalized;
}

function normalizeDataset(items) {
  console.log(`\n🔍 [Normalizer] Processing ${items.length} items...`);
  
  const normalized = items.map(normalizeWorkOrder);

  // Filter out items with no deal name
  const filtered = normalized.filter(item => item.dealName !== 'Unnamed Deal');

  console.log(`✅ [Normalizer] Normalized ${normalized.length} items, kept ${filtered.length} with valid names`);
  
  if (filtered.length > 0) {
    console.log('\n📊 [Normalizer] Sample normalized item:');
    console.log(JSON.stringify(filtered[0], null, 2));
    
    console.log('\n📈 [Normalizer] Data Summary:');
    const sectors = [...new Set(filtered.map(d => d.sector).filter(s => s !== 'Unclassified'))];
    const statuses = [...new Set(filtered.map(d => d.executionStatus))];
    console.log(`   - Total Records: ${filtered.length}`);
    console.log(`   - Sectors: ${sectors.join(', ') || 'None'}`);
    console.log(`   - Execution Statuses: ${statuses.join(', ')}`);
    console.log(`   - Total Amount (Excl GST): ${filtered.reduce((sum, d) => sum + d.amountExclGST, 0).toFixed(2)}`);
  }
  
  return filtered;
}

module.exports = { normalizeWorkOrder, normalizeDataset };