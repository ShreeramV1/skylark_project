require('dotenv').config();
const express = require('express');
const cors = require('cors');
const BIAgent = require('./bi-agent');

const app = express();
app.use(cors());
app.use(express.json());

console.log('\n🚀 [Server] Starting Monday.com BI Agent Server...');
console.log(`📅 [Server] Timestamp: ${new Date().toISOString()}`);

// Validate environment variables
const requiredEnvVars = [
  'MONDAY_API_TOKEN',
  'GEMINI_API_KEY',
  'MONDAY_BOARD_ID',
  'MONDAY_DEALS_BOARD_ID'
];

const missingVars = requiredEnvVars.filter(v => !process.env[v]);
if (missingVars.length > 0) {
  console.error('❌ [Server] Missing environment variables:', missingVars.join(', '));
  console.error('❌ [Server] Please add these to Render dashboard');
  process.exit(1);
}

console.log('✅ [Server] All environment variables validated');
console.log(`   - MONDAY_API_TOKEN: ${process.env.MONDAY_API_TOKEN ? '✓' : '✗'}`);
console.log(`   - GEMINI_API_KEY: ${process.env.GEMINI_API_KEY ? '✓' : '✗'}`);
console.log(`   - MONDAY_BOARD_ID: ${process.env.MONDAY_BOARD_ID}`);
console.log(`   - MONDAY_DEALS_BOARD_ID: ${process.env.MONDAY_DEALS_BOARD_ID}`);

let agent;
try {
  agent = new BIAgent();
  console.log('✅ [Server] BIAgent initialized successfully');
} catch (error) {
  console.error('❌ [Server] Failed to initialize BIAgent:', error.message);
  console.error(error.stack);
  process.exit(1);
}

// Health check endpoint (no data fetching)
app.get('/api/health', (req, res) => {
  console.log('🏥 [Health Check] Received');
  res.json({ 
    status: 'ok',
    timestamp: new Date().toISOString(),
    workOrdersBoard: process.env.MONDAY_BOARD_ID,
    dealsBoard: process.env.MONDAY_DEALS_BOARD_ID,
    conversationLength: agent.conversationHistory.length,
    environment: process.env.NODE_ENV || 'development'
  });
});

// Main query endpoint
app.post('/api/query', async (req, res) => {
  const { message } = req.body;
  const requestId = Date.now();

  console.log(`\n[Request #${requestId}] New query received`);
  console.log(`[Request #${requestId}] Message: "${message}"`);

  if (!message || message.trim().length === 0) {
    console.warn(`[Request #${requestId}] ❌ Empty message`);
    return res.status(400).json({ error: 'Message required' });
  }

  try {
    console.log(`[Request #${requestId}] Processing with BIAgent...`);
    const result = await agent.answerQuery(message);
    console.log(`[Request #${requestId}] ✅ Response sent successfully`);
    res.json(result);
  } catch (error) {
    console.error(`[Request #${requestId}] ❌ Error in BIAgent:`, error.message);
    console.error(`[Request #${requestId}] Stack:`, error.stack);
    
    // Send detailed error to client
    res.status(500).json({ 
      error: 'Failed to process query',
      details: error.message,
      requestId: requestId
    });
  }
});

// Clear history endpoint
app.post('/api/clear-history', (req, res) => {
  console.log('🗑️ [Server] Clearing conversation history');
  agent.clearHistory();
  res.json({ 
    status: 'ok',
    message: 'Conversation history cleared'
  });
});

// Get history endpoint
app.get('/api/history', (req, res) => {
  const history = agent.getHistory();
  res.json({ 
    status: 'ok',
    conversationLength: history.length,
    history: history
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('🔴 [Server] Unhandled error:', err.message);
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message,
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use((req, res) => {
  console.warn(`⚠️ [Server] 404 - ${req.method} ${req.path}`);
  res.status(404).json({
    error: 'Not found',
    path: req.path,
    availableEndpoints: [
      'GET /api/health',
      'POST /api/query',
      'GET /api/history',
      'POST /api/clear-history'
    ]
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`\n✅ [Server] BI Agent running on http://localhost:${PORT}`);
  console.log(`📝 [Server] API endpoints:`);
  console.log(`   - GET    /api/health (check status)`);
  console.log(`   - POST   /api/query (ask questions)`);
  console.log(`   - GET    /api/history (view conversation)`);
  console.log(`   - POST   /api/clear-history (reset chat)\n`);
});