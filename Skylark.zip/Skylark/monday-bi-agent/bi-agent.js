const { GoogleGenerativeAI } = require('@google/generative-ai');
const { getWorkOrdersData, getDealsData } = require('./monday-client');
const { normalizeDataset } = require('./data-normalizer');
const { normalizeDealsDataset } = require('./data-normalizer-deals');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

class BIAgent {
  constructor() {
    this.conversationHistory = [];
    this.workOrdersCache = null;
    this.dealsCache = null;
    this.model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash-lite' });
    this.maxHistoryExchanges = 3; // Keep last 3 exchanges (6 messages: 3 user + 3 assistant)
    console.log(`🤖 [BI Agent] Initialized with dual-board integration`);
    console.log(`🧠 [BI Agent] Using Gemini 1.5 Flash model`);
    console.log(`💾 [BI Agent] Conversation memory: Last ${this.maxHistoryExchanges} exchanges`);
  }

  addToHistory(role, content) {
    this.conversationHistory.push({
      role: role,
      content: content,
    });

    // Keep only last 3 exchanges (6 messages total: user + assistant pairs)
    const maxMessages = this.maxHistoryExchanges * 2;
    if (this.conversationHistory.length > maxMessages) {
      const removed = this.conversationHistory.splice(0, this.conversationHistory.length - maxMessages);
      console.log(`📝 [BI Agent] Trimmed history - removed ${removed.length} old message(s)`);
    }
  }

  getFormattedHistory() {
    // Format history for context in the prompt
    if (this.conversationHistory.length === 0) {
      return 'No previous conversation history.';
    }

    let history = 'Recent conversation history:\n';
    this.conversationHistory.forEach((msg, idx) => {
      const role = msg.role === 'user' ? 'User' : 'Assistant';
      history += `\n${idx + 1}. ${role}: ${msg.content.substring(0, 150)}${msg.content.length > 150 ? '...' : ''}\n`;
    });

    return history;
  }

  async fetchLatestData() {
    console.log('⏳ [BI Agent] Fetching latest data from both boards...');
    try {
      // Fetch Work Orders
      console.log('📋 [BI Agent] Fetching Work Orders...');
      const woResponse = await getWorkOrdersData();
      const woItems = woResponse.data?.boards?.[0]?.items_page?.items || [];
      this.workOrdersCache = normalizeDataset(woItems);
      console.log(`✅ [BI Agent] Work Orders: ${this.workOrdersCache.length} records`);

      // Fetch Deals
      console.log('📋 [BI Agent] Fetching Deals...');
      const dealsResponse = await getDealsData();
      const dealsItems = dealsResponse.data?.boards?.[0]?.items_page?.items || [];
      this.dealsCache = normalizeDealsDataset(dealsItems);
      console.log(`✅ [BI Agent] Deals: ${this.dealsCache.length} records`);

      return { workOrders: this.workOrdersCache, deals: this.dealsCache };
    } catch (error) {
      console.error('⚠️ [BI Agent] Failed to fetch data:', error.message);
      return { 
        workOrders: this.workOrdersCache || [], 
        deals: this.dealsCache || [] 
      };
    }
  }

  generateDataAnalysis(workOrders, deals) {
    const analysis = {
      workOrders: {
        total: workOrders.length,
        sectors: {},
        statuses: {},
        totalAmount: 0,
        totalBilled: 0,
        totalCollected: 0,
      },
      deals: {
        total: deals.length,
        sectors: {},
        statuses: {},
        totalValue: 0,
        byProbability: {},
      },
    };

    // Analyze Work Orders
    workOrders.forEach(record => {
      const sector = record.sector || 'Unclassified';
      if (!analysis.workOrders.sectors[sector]) {
        analysis.workOrders.sectors[sector] = { count: 0, amount: 0, billed: 0, collected: 0 };
      }
      analysis.workOrders.sectors[sector].count += 1;
      analysis.workOrders.sectors[sector].amount += record.amountExclGST || 0;
      analysis.workOrders.sectors[sector].billed += record.billedValueExclGST || 0;
      analysis.workOrders.sectors[sector].collected += record.collectedAmount || 0;

      const status = record.executionStatus || 'Unknown';
      analysis.workOrders.statuses[status] = (analysis.workOrders.statuses[status] || 0) + 1;

      analysis.workOrders.totalAmount += record.amountExclGST || 0;
      analysis.workOrders.totalBilled += record.billedValueExclGST || 0;
      analysis.workOrders.totalCollected += record.collectedAmount || 0;
    });

    // Analyze Deals
    deals.forEach(record => {
      const sector = record.sector || 'Unclassified';
      if (!analysis.deals.sectors[sector]) {
        analysis.deals.sectors[sector] = { count: 0, value: 0 };
      }
      analysis.deals.sectors[sector].count += 1;
      analysis.deals.sectors[sector].value += record.dealValue || 0;

      const status = record.dealStatus || 'Unknown';
      analysis.deals.statuses[status] = (analysis.deals.statuses[status] || 0) + 1;

      const prob = record.closureProbability || 'Unknown';
      analysis.deals.byProbability[prob] = (analysis.deals.byProbability[prob] || 0) + 1;

      analysis.deals.totalValue += record.dealValue || 0;
    });

    return analysis;
  }

  async answerQuery(userQuery) {
    console.log(`\n💬 [BI Agent] Processing query: "${userQuery}"`);
    console.log(`📝 [BI Agent] Current conversation history length: ${this.conversationHistory.length}`);
    
    const { workOrders, deals } = await this.fetchLatestData();

    if (workOrders.length === 0 && deals.length === 0) {
      console.warn('⚠️ [BI Agent] No data available');
      this.addToHistory('user', userQuery);
      const errorResponse = 'Sorry, I cannot access data from monday.com at the moment. Please check your API credentials and board IDs.';
      this.addToHistory('model', errorResponse);
      return {
        answer: errorResponse,
        dataQuality: { totalRecords: 0, completeRecords: 0 },
      };
    }

    const analysis = this.generateDataAnalysis(workOrders, deals);

    const systemPrompt = `You are a business intelligence assistant for monday.com work order and deals pipeline data.

You have access to TWO datasets:

**1. WORK ORDERS (Executed Projects)**
- Project execution data with status tracking
- Financial metrics: amounts, billing, collection
- Execution status and timeline data
- Sector information

**2. DEALS (Sales Pipeline)**
- Deal pipeline data with closure probabilities
- Deal stages from Lead to Won
- Deal values and closure forecasts
- Sector/service information

**WORK ORDERS DATA SUMMARY:**
- Total Records: ${analysis.workOrders.total}
- Total Project Value (Excl GST): ₹${analysis.workOrders.totalAmount.toFixed(2)}
- Total Billed: ₹${analysis.workOrders.totalBilled.toFixed(2)}
- Total Collected: ₹${analysis.workOrders.totalCollected.toFixed(2)}
- Sectors: ${Object.keys(analysis.workOrders.sectors).join(', ')}

**DEALS DATA SUMMARY:**
- Total Deals: ${analysis.deals.total}
- Total Pipeline Value: ₹${analysis.deals.totalValue.toFixed(2)}
- Deal Statuses: ${Object.keys(analysis.deals.statuses).join(', ')}
- Sectors: ${Object.keys(analysis.deals.sectors).join(', ')}

**PREVIOUS CONVERSATION CONTEXT:**
${this.getFormattedHistory()}

**FORMATTING RULES:**
1. Use clean, organized sections with markdown
2. Use tables for comparative data
3. Use bullet points for lists
4. Focus only on relevant information
5. Use currency notation (₹) for amounts
6. Start with executive summary
7. If the user is asking a follow-up question, maintain context from previous exchanges
8. Reference previous queries when relevant
9. Avoid unnecessary caveats unless specifically asked`;

    const dataContext = `Sample Work Orders:\n${JSON.stringify(workOrders.slice(0, 2), null, 2)}\n\nSample Deals:\n${JSON.stringify(deals.slice(0, 2), null, 2)}`;
    const fullPrompt = `${systemPrompt}\n\n${dataContext}\n\nCurrent User Query: ${userQuery}\n\nProvide a clean, well-formatted response using markdown. If this is a follow-up question, use the conversation history above to maintain context.`;

    try {
      console.log('🧠 [Gemini API] Sending request to Gemini with conversation context...');
      const result = await this.model.generateContent(fullPrompt);
      const response = result.response;
      const assistantMessage = response.text();

      // Add to conversation history
      this.addToHistory('user', userQuery);
      this.addToHistory('model', assistantMessage);

      console.log('✅ [Gemini API] Response generated successfully');
      console.log(`💾 [BI Agent] Saved to history - Total messages: ${this.conversationHistory.length}`);

      return {
        answer: assistantMessage,
        dataQuality: {
          totalRecords: workOrders.length + deals.length,
          completeRecords: workOrders.filter(d => Object.values(d).filter(v => v && v !== 'N/A').length > 5).length + 
                          deals.filter(d => Object.values(d).filter(v => v && v !== 'N/A').length > 5).length,
        },
      };
    } catch (error) {
      console.error('❌ [Gemini API] Request failed:', error.message);
      this.addToHistory('user', userQuery);
      this.addToHistory('model', `Error: ${error.message}`);
      throw error;
    }
  }

  // Method to clear history if needed
  clearHistory() {
    console.log('🗑️ [BI Agent] Clearing conversation history');
    this.conversationHistory = [];
  }

  // Method to get current history for debugging
  getHistory() {
    return this.conversationHistory;
  }
}

module.exports = BIAgent;