import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import './App.css';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      console.log('📤 Sending request to:', process.env.REACT_APP_API_URL || 'https://skylark-5aah.onrender.com');
      
      const response = await fetch('https://skylark-5aah.onrender.com/api/query', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: input }),
      });

      console.log('Response status:', response.status);
      const data = await response.json();
      console.log('Response data:', data);

      if (!response.ok) {
        throw new Error(data.details || data.error || 'API error');
      }

      const assistantMessage = {
        role: 'assistant',
        content: data.answer,
        dataQuality: data.dataQuality,
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('❌ Request failed:', error);
      const errorMessage = {
        role: 'assistant',
        content: `❌ Error: ${error.message}\n\n**Debugging Info:**\n- Check Render logs: https://dashboard.render.com\n- Verify environment variables are set\n- Request ID: ${Date.now()}`,
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <div className="chat-wrapper">
        <div className="chat-container">
          <div className="chat-messages">
            {messages.length === 0 && (
              <div className="welcome-message">
                <div className="welcome-header">
                  <h1>📊 BI Agent</h1>
                  <p>Powered by Monday.com & Google Gemini</p>
                </div>
                <div className="welcome-content">
                  <div className="example-section">
                    <h3>Examples</h3>
                    <button className="example-btn" onClick={() => setInput("How's our pipeline for the energy sector?")}>
                      "How's our pipeline for the energy sector?"
                    </button>
                    <button className="example-btn" onClick={() => setInput("What's our total billed amount this month?")}>
                      "What's our total billed amount this month?"
                    </button>
                    <button className="example-btn" onClick={() => setInput("Which deals are most likely to close?")}>
                      "Which deals are most likely to close?"
                    </button>
                    <button className="example-btn" onClick={() => setInput("Compare work orders vs deal pipeline")}>
                      "Compare work orders vs deal pipeline"
                    </button>
                  </div>
                  <div className="capabilities-section">
                    <h3>Capabilities</h3>
                    <ul>
                      <li>📊 Analyze work orders & deal pipelines</li>
                      <li>💬 Follow-up questions with context memory</li>
                      <li>📈 Cross-sector analysis & insights</li>
                      <li>💾 Conversation history management</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {messages.map((msg, idx) => (
              <div key={idx} className={`message-wrapper ${msg.role}`}>
                <div className="message-avatar">
                  {msg.role === 'user' ? '👤' : '🤖'}
                </div>
                <div className={`message ${msg.role}`}>
                  <div className="message-content">
                    {msg.role === 'assistant' ? (
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>
                        {msg.content}
                      </ReactMarkdown>
                    ) : (
                      msg.content
                    )}
                  </div>
                  {msg.dataQuality && (
                    <div className="data-quality">
                      <small>
                        📊 {msg.dataQuality.totalRecords} records analyzed
                      </small>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {loading && (
              <div className="message-wrapper assistant">
                <div className="message-avatar">🤖</div>
                <div className="message assistant loading">
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="chat-input-section">
            <form onSubmit={handleSendMessage} className="chat-input-form">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask a business question..."
                disabled={loading}
              />
              <button type="submit" disabled={loading} className="send-button">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M.5 1.163A.5.5 0 0 1 1.97.97l12.868 6.837a.5.5 0 0 1 0 .906L1.969 15.03A.5.5 0 0 1 .5 14.836V10.33a.5.5 0 0 0-.5-.5H.5v-9z" fill="currentColor"/>
                </svg>
              </button>
            </form>
            <p className="footer-text">BI Agent can make mistakes. Please verify important information.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
