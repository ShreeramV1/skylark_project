# Monday.com Business Intelligence Agent - Decision Log

## 1. Key Assumptions Made

### Data Quality & Structure
- **Assumption**: Work Orders and Deals boards contain messy, real-world data with missing values, inconsistent formats, and null fields.
  - **Rationale**: Problem statement explicitly stated "The data is real-world messy data - Your agent must handle this gracefully."
  - **Implementation**: Built robust normalizers with cleaning functions (cleanValue, parseAmount) that handle nulls, empty strings, and inconsistent data types.

### User Intent & Query Interpretation
- **Assumption**: Users would ask founder-level business questions that span multiple data sources and require context awareness.
  - **Rationale**: Problem statement emphasized "Founders and executives need quick, accurate answers" and "interpret that query, find relevant data across multiple boards."
  - **Implementation**: Integrated both Work Orders and Deals boards into single agent with multi-dataset analysis capabilities.

### Conversation Context Importance
- **Assumption**: Users would ask follow-up questions requiring memory of previous exchanges rather than isolated queries.
  - **Rationale**: Natural conversation flow for business analysis - "Tell me more about X" or "And what about Y?"
  - **Implementation**: Added conversation history management maintaining last 3 exchanges with full context passing to LLM.

### Column Mapping Variability
- **Assumption**: Monday.com column IDs would differ between boards and might not match expected field names.
  - **Rationale**: Real-world monday.com usage has flexible column structures per board.
  - **Implementation**: Extracted exact column IDs from API before normalizing, created separate normalizers for each board.

### AI Model Choice
- **Assumption**: Google Gemini 1.5 Flash would be more reliable than Claude for this use case given free tier limitations.
  - **Rationale**: User had zero Claude credits; Gemini offers generous free tier (60 req/min) and sufficient capability for BI tasks.
  - **Implementation**: Used Gemini API with flash model for cost efficiency and speed.

---

## 2. Trade-offs Chosen & Rationale

### Trade-off 1: Normalization Strictness vs Data Retention
**Choice**: Relaxed filtering to keep all items with valid names, even if some fields are missing.

**Why**: 
- Initial implementation filtered too aggressively (346 deals → 0 records), losing all data
- Real-world data always has missing fields; BI must work with partial data
- Better to show incomplete data than no data

**Implementation**: Filter only checks for valid dealName/itemName, allows null values in other fields

---

### Trade-off 2: Real-time vs Cached Data
**Choice**: Fetch fresh data on every query with caching fallback.

**Why**:
- Real-time ensures users see latest pipeline status (critical for executives)
- Caching prevents complete failure if API temporarily unavailable
- Trade cost (multiple API calls) for reliability and freshness

**Code Impact**: `fetchLatestData()` always queries API, stores in cache automatically

---

### Trade-off 3: Conversation History Scope
**Choice**: Keep last 3 exchanges (6 messages) instead of full session history.

**Why**:
- Full history → token bloat → slower responses + higher costs
- 3 exchanges sufficient for follow-up context without excessive overhead
- Prevents confusion from too-old context becoming irrelevant

**Implementation**: Auto-trim history when exceeding 6 messages, log removal for transparency

---

### Trade-off 4: Response Format Control
**Choice**: Let Gemini format responses with minimal constraints, rely on system prompt for formatting guidance.

**Why**:
- Over-constraining format in prompt can limit response quality
- Gemini markdown support is excellent - tables render beautifully with react-markdown + remark-gfm
- Users can always ask "format as table" if unsatisfied

**Result**: Clean, natural responses with proper markdown rendering

---

### Trade-off 5: Single Agent vs Multi-Agent Architecture
**Choice**: Single BIAgent class managing both boards rather than separate agents.

**Why**:
- Simpler implementation, single conversation context
- Cross-board analysis (Work Orders vs Deals comparison) is easier
- Trades specialization for integration benefits

**Complexity**: Added `generateDataAnalysis()` to handle dual-dataset aggregation

---

### Trade-off 6: Authentication & API Key Management
**Choice**: Store API keys in .env file (not production-safe, but project requirement).

**Why**:
- Problem statement focused on functionality, not infrastructure
- .env is standard dev practice; noted as security consideration
- Could be upgraded to AWS Secrets Manager / HashiCorp Vault with more time

---

## 3. What We'd Do Differently With More Time

### Performance Optimizations
1. **Pagination**: Implement cursor-based pagination for large datasets (currently fetches all 346+ items at once)
   - **Impact**: Reduce API response time, handle boards with 10,000+ records

2. **Query Optimization**: Cache analysis results for 5-minute windows
   - **Impact**: Avoid re-analyzing identical datasets on rapid-fire queries
   - **Tradeoff**: Add complexity of cache invalidation logic

3. **Database Layer**: Store normalized data in PostgreSQL/MongoDB
   - **Impact**: Complex queries much faster, historical trending analysis possible
   - **Current limitation**: All analysis is point-in-time only

### Feature Enhancements
4. **Multi-User Support**: Currently single session, no user isolation
   - **Would add**: User IDs, separate conversation histories per user, access control
   - **Impact**: Production-ready for team use

5. **Sector/Status Autocomplete**: Suggest valid values when users misspell sectors
   - **Would add**: Fuzzy matching, suggestions in response
   - **Impact**: Better UX, fewer "no results" scenarios

6. **Deal Probability Weighting**: Weight pipeline value by closure probability
   - **Current**: Treats high-prob and low-prob deals equally
   - **Enhancement**: Adjusted pipeline metrics for realistic forecasting

7. **Drill-Down Capability**: "Show me the 6 deals in Renewables sector with High probability"
   - **Current**: Can't filter to specific subsets
   - **Would require**: Advanced query parsing, data filtering layer

### Analytics & Insights
8. **Trend Analysis**: Month-over-month pipeline growth, won deal patterns
   - **Requires**: Historical data storage + time-series analysis
   - **Impact**: Executive dashboarding capabilities

9. **Predictive Models**: ML-based deal close date forecasting
   - **Current**: Gemini uses historical patterns only
   - **Enhancement**: Train on actual close dates vs predicted

10. **Anomaly Detection**: Flag unusual patterns (sudden collection drop, won deals with 0 value)
    - **Current**: No validation or warning system
    - **Would add**: Data quality alerts

### Infrastructure & DevOps
11. **Error Logging & Monitoring**: Sentry/DataDog integration for production observability
    - **Current**: Only console logs
    - **Impact**: Easier debugging when things fail silently

12. **Rate Limiting**: Protect against API abuse or runaway costs
    - **Would add**: Request throttling, Gemini token budget tracking
    - **Impact**: Control spend, prevent accidents

13. **Webhook Integration**: Real-time board updates instead of polling
    - **Current**: Pull-based (fetch on query)
    - **Enhancement**: Push-based (webhook on deal/WO change)

14. **Deployment**: Docker containerization + Kubernetes orchestration
    - **Current**: Local Node.js only
    - **Would enable**: Horizontal scaling, zero-downtime deploys

---

## 4. How We Interpreted "Leadership Updates"

### Definition Applied
"Leadership updates" = **Clean, actionable executive summaries** that answer business questions without technical jargon or excessive caveats.

### Specific Interpretations

#### **Summary-First Approach**
- Lead with headline metrics (total pipeline value, deal count, status breakdown)
- Executive sees answer in first 10 seconds
- Details available below if interested

**Example**:
```
Executive Summary
Total Energy Sector Pipeline: ₹93.5M across 51 deals
Key Insight: Renewables has highest value (₹77.1M billed to date)
```

Rather than:
```
The data shows various sectors... some deals are on hold... 
considering we have 346 total deals with some missing values...
```

---

#### **Avoid Data Quality Caveats** (Unless Critical)
- **Our approach**: Only mention data issues if they materially affect the answer
- **Example**: If asking "How much have we collected?" and collection field is 95% complete, don't mention the 5% gaps
- **Counter-example**: If asking "What's our DSP sector revenue?" and 40% of DSP records missing sectors, DO flag this

**Implementation**: BI Agent includes caveats only when `dataQuality.completeRecords < 50%`

---

#### **Formatted for Readability**
- Use markdown tables for comparisons
- Use bullet points for lists
- Use sections with headers for organization
- **Rationale**: Executives often have < 5 minutes per dashboard; visual hierarchy is critical

---

#### **Conversation-First Design**
- Ask follow-up questions to refine understanding
- Remember previous context across exchanges
- Build on prior answers rather than starting fresh

**Example flow**:
```
User: "How's our energy pipeline?"
Agent: [Shows summary] "Would you like to drill into high-probability deals?"

User: "Yes, and compare to mining"
Agent: [Maintains energy context, adds mining comparison]
```

---

#### **Cross-Board Intelligence**
- Don't just answer from one board
- Synthesize insights across Work Orders + Deals
- Highlight disconnects (e.g., "Energy sector has $10M in deals but only $2M in active work orders")

**This is "leadership" because**: Executives care about pipeline-to-execution conversion, not raw metrics

---

### Decision Implications

**What we DID include in responses:**
- Executive summaries with key numbers
- Trend insights ("Renewables outperforming Mining")
- Comparative analysis across sectors/statuses
- Follow-up questions to clarify intent
- Tables with relevant subsets of data

**What we AVOIDED:**
- Listing every single record (too verbose)
- Technical details about column IDs or normalization
- Disclaimers about every missing value
- Unexplained jargon (e.g., "Closure Probability" → "likelihood of deal closing")
- Multiple formatting options (picked markdown as standard)

---

## Summary

This BI agent balances **data resilience** (handles messy real-world data gracefully) with **executive usability** (answers questions in < 10 seconds with clear insights). We traded feature breadth for depth, architectural complexity for simplicity, and production-readiness for speed-to-delivery—appropriate choices for an MVP solving a specific founder pain point.

Key success criterion met: **Non-technical founder can ask natural business questions and get actionable answers from two integrated data sources.**

---

**Decision Log Completed**  
Date: April 27, 2026  
Project: Monday.com Business Intelligence Agent  
Status: ✅ Complete
